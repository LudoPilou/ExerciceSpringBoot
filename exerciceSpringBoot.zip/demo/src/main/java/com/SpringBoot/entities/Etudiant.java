package com.SpringBoot.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Etudiant {

	
	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	@Column(name="id_etu")
	private Long id; 
	
	private String nom;
	private String prenom;
	private Date dateNaissance;
	
	@ManyToOne 
	private Section section;
	
	@ManyToMany
	@JoinTable (name="ETU_EXAM" , 
			joinColumns=@JoinColumn(name="etu_id" ,referencedColumnName="id_etu"),
		    inverseJoinColumns=@JoinColumn(name="epr_id" ,referencedColumnName="id_epr")
			)
	private List<Epreuve> listEpreuve;

	public Etudiant(Long id, String nom, String prenom, Date dateNaissance, Section section) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateNaissance;
		this.section = section;
	}

	public Etudiant() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public Date getDateNaissance() {
		return dateNaissance;
	}

	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}

	public Section getSection() {
		return section;
	}

	public void setSection(Section section) {
		this.section = section;
	}

	@Override
	public String toString() {
		return "Etudiant [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", dateNaissance=" + dateNaissance + "]";
	}
	
	
	

	

	
	
	
	
}
