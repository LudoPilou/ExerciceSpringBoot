package com.SpringBoot.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Matiere {

	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	private Long id;
	private String Libelle;
	private float duree;
	private float coefficient;
	
	@ManyToMany (mappedBy = "listMatiere")
	private List<Section> listSection;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="id_epr")
	private Epreuve epreuve;

	public Matiere(Long id, String libelle, float duree, float coefficient, List<Section> listSection,
			Epreuve epreuve) {
		super();
		this.id = id;
		Libelle = libelle;
		this.duree = duree;
		this.coefficient = coefficient;
		this.listSection = listSection;
		this.epreuve = epreuve;
	}

	public Matiere() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLibelle() {
		return Libelle;
	}

	public void setLibelle(String libelle) {
		Libelle = libelle;
	}

	public float getDuree() {
		return duree;
	}

	public void setDuree(float duree) {
		this.duree = duree;
	}

	public float getCoefficient() {
		return coefficient;
	}

	public void setCoefficient(float coefficient) {
		this.coefficient = coefficient;
	}

	public List<Section> getListSection() {
		return listSection;
	}

	public void setListSection(List<Section> listSection) {
		this.listSection = listSection;
	}

	public Epreuve getEpreuve() {
		return epreuve;
	}

	public void setEpreuve(Epreuve epreuve) {
		this.epreuve = epreuve;
	}

	@Override
	public String toString() {
		return "Matiere [id=" + id + ", Libelle=" + Libelle + ", duree=" + duree + ", coefficient=" + coefficient + "]";
	}
	
	
	
	
	
	
	
}
