package com.SpringBoot.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Section {

	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	private Long id; 
	private String libelle;
	
	@OneToMany (mappedBy="section",cascade=CascadeType.ALL)
	private List<Etudiant> listEtud;
	
	@ManyToMany (cascade = CascadeType.ALL)
	private List<Matiere> listMatiere;

	public Section(Long id, String libelle, List<Etudiant> listEtud, List<Matiere> listMatiere) {
		super();
		this.id = id;
		this.libelle = libelle;
		this.listEtud = listEtud;
		this.listMatiere = listMatiere;
	}

	public Section() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public List<Etudiant> getListEtud() {
		return listEtud;
	}

	public void setListEtud(List<Etudiant> listEtud) {
		this.listEtud = listEtud;
	}

	public List<Matiere> getListMatiere() {
		return listMatiere;
	}

	public void setListMatiere(List<Matiere> listMatiere) {
		this.listMatiere = listMatiere;
	}

	@Override
	public String toString() {
		return "Section [id=" + id + ", libelle=" + libelle + "]";
	}
	
	
	
	
	
	
	
	
	
}
