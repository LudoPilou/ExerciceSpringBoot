package com.SpringBoot.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Laboratoire {

	
	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	@Column(name="id_labo")
	private Long id;
	private String nomLabo;
	private int nbrOrdi;
	
	@ManyToOne
	@JoinColumn(name="id_epr")
	private List<Epreuve> listEp;

	public Laboratoire(Long id, String nomLabo, int nbrOrdi, List<Epreuve> listEp) {
		super();
		this.id = id;
		this.nomLabo = nomLabo;
		this.nbrOrdi = nbrOrdi;
		this.listEp = listEp;
	}

	public Laboratoire() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomLabo() {
		return nomLabo;
	}

	public void setNomLabo(String nomLabo) {
		this.nomLabo = nomLabo;
	}

	public int getNbrOrdi() {
		return nbrOrdi;
	}

	public void setNbrOrdi(int nbrOrdi) {
		this.nbrOrdi = nbrOrdi;
	}

	public List<Epreuve> getListEp() {
		return listEp;
	}

	public void setListEp(List<Epreuve> listEp) {
		this.listEp = listEp;
	}

	@Override
	public String toString() {
		return "Laboratoire [id=" + id + ", nomLabo=" + nomLabo + ", nbrOrdi=" + nbrOrdi + "]";
	}
	
	
	
	
}
