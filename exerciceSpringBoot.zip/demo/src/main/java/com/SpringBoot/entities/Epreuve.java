package com.SpringBoot.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Epreuve {

	
	@Id
	@GeneratedValue (strategy=GenerationType.IDENTITY)
	@Column(name="id_epr")
	private Long id;
	private Date dateEpreuve;
	
	@OneToOne (mappedBy ="epreuve")
	private Matiere matiere;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="id_labo")
	private Laboratoire laboratoire;
	
	@ManyToMany (mappedBy="id_etu")
	private List<Etudiant> listEtuds;

	public Epreuve(Long id, Date dateEpreuve, Matiere matiere, Laboratoire laboratoire) {
		super();
		this.id = id;
		this.dateEpreuve = dateEpreuve;
		this.matiere = matiere;
		this.laboratoire = laboratoire;
	}

	public Epreuve() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDateEpreuve() {
		return dateEpreuve;
	}

	public void setDateEpreuve(Date dateEpreuve) {
		this.dateEpreuve = dateEpreuve;
	}

	public Matiere getMatiere() {
		return matiere;
	}

	public void setMatiere(Matiere matiere) {
		this.matiere = matiere;
	}

	public Laboratoire getLaboratoire() {
		return laboratoire;
	}

	public void setLaboratoire(Laboratoire laboratoire) {
		this.laboratoire = laboratoire;
	}

	@Override
	public String toString() {
		return "Epreuve [id=" + id + ", dateEpreuve=" + dateEpreuve + "]";
	}
	
	
	
	
	
	
}
