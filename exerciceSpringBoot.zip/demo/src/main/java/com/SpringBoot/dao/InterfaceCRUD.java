package com.SpringBoot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpringBoot.entities.Etudiant;

public interface InterfaceCRUD<T> extends JpaRepository<T, Long>{

	
	
}
