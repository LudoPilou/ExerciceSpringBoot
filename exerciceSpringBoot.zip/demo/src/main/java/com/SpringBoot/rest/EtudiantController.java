package com.SpringBoot.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.entities.Etudiant;

import com.SpringBoot.service.IEleveService;

@RestController
public class EtudiantController {

	@Autowired
	IEleveService<Etudiant> etudiantServ;
	
	

	@GetMapping("/api/get/{id}")
	public Etudiant findOneById(@PathVariable Long id) {
		return etudiantServ.findOneById(id);
	}

	@PostMapping("/api/save")
	public Etudiant save(@RequestBody Etudiant p) {
		return etudiantServ.save(p);
	}

	@DeleteMapping("/api/delete")
	public void delete(@RequestBody Etudiant p) {
		etudiantServ.delete(p);
	}

	@GetMapping("/api/getall")
	public List<Etudiant> getAll() {
		return etudiantServ.getAll();
	}

	
}
