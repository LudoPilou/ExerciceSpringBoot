package com.SpringBoot.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBoot.entities.Matiere;

import com.SpringBoot.service.IMatiereService;

@RestController
public class MatiereController {

	@Autowired
	IMatiereService<Matiere> matiereServ;
	
	@GetMapping("/api/get/{id}")
	public Matiere findOneById(@PathVariable Long id) {
		return matiereServ.findOneById(id);
	}

	@PostMapping("/api/save")
	public Matiere save(@RequestBody Matiere p) {
		return matiereServ.save(p);
	}

	@DeleteMapping("/api/delete")
	public void delete(@RequestBody Matiere p) {
		matiereServ.delete(p);
	}

	@GetMapping("/api/getall")
	public List<Matiere> getAll() {
		return matiereServ.getAll();
	}
	
}
