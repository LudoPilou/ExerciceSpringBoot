package com.SpringBoot.service;



public interface IMatiereService<Matiere> extends InterfGeneService<Matiere>{

	
	
}
