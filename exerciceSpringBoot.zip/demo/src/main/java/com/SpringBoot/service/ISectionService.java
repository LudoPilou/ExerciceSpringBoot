package com.SpringBoot.service;

public interface ISectionService<Section> extends InterfGeneService<Section>{

	
	
}
