package com.SpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.dao.InterfaceCRUD;

@Service
public class EpreuveService<Epreuve> implements IEpreuveService<Epreuve> {

	@Autowired
	InterfaceCRUD<Epreuve> epreuveDao;
	
	
	
	@Override
	public Epreuve findOneById(Long id) {
	
		return epreuveDao.getOne(id);
	}

	@Override
	public Epreuve save(Epreuve t) {
		
		return epreuveDao.save(t);
	}

	@Override
	public void delete(Epreuve t) {
		epreuveDao.delete(t);
		
	}

	@Override
	public List<Epreuve> getAll() {
	
		return epreuveDao.findAll();
	}

}
