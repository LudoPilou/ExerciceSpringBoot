package com.SpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.dao.InterfaceCRUD;

@Service
public class EleveService<Etudiant> implements IEleveService<Etudiant>{

	@Autowired
	InterfaceCRUD<Etudiant> etuDao;
	
	@Override
	public Etudiant findOneById(Long id) {
		
		return etuDao.getOne(id);
	}

	@Override
	public Etudiant save(Etudiant t) {
	
		return etuDao.save(t);
	}

	@Override
	public void delete(Etudiant t) {
		etuDao.delete(t);
		
	}

	@Override
	public List<Etudiant> getAll() {
		
		return etuDao.findAll();
	}


}
