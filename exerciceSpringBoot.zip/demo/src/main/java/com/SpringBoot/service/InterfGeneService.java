package com.SpringBoot.service;

import java.util.List;



public interface InterfGeneService<T> {


	public T findOneById(Long id);
	public T save(T t);
	public void delete(T t);
	public List<T> getAll();
}
