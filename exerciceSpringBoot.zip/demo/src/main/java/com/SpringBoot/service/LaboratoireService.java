package com.SpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.dao.InterfaceCRUD;

@Service
public class LaboratoireService<Laboratoire> implements ILaboratoireService<Laboratoire>{

	@Autowired
	InterfaceCRUD<Laboratoire> laboratoireDao;
	
	
	@Override
	public Laboratoire findOneById(Long id) {
		
		return laboratoireDao.getOne(id);
	}

	@Override
	public Laboratoire save(Laboratoire t) {
		
		return laboratoireDao.save(t);
	}

	@Override
	public void delete(Laboratoire t) {
		laboratoireDao.delete(t);
		
	}

	@Override
	public List<Laboratoire> getAll() {
		
		return laboratoireDao.findAll();
	}

}
