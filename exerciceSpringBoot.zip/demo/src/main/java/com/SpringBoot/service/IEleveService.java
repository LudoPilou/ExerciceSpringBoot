package com.SpringBoot.service;

public interface IEleveService<Etudiant> extends InterfGeneService<Etudiant>{

	
	
}
