package com.SpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.dao.InterfaceCRUD;

@Service
public class SectionService<Section> implements ISectionService<Section>{

	@Autowired
	InterfaceCRUD<Section> sectionDao;
	
	
	@Override
	public Section findOneById(Long id) {
		
		return sectionDao.getOne(id);
	}

	@Override
	public Section save(Section t) {
		
		return sectionDao.save(t);
	}

	@Override
	public void delete(Section t) {
		sectionDao.delete(t);
		
	}

	@Override
	public List<Section> getAll() {
		
		return sectionDao.findAll();
	}

}
