package com.SpringBoot.service;

public interface IEpreuveService<Epreuve> extends InterfGeneService<Epreuve>{

}
