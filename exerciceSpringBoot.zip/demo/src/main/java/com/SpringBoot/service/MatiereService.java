package com.SpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot.dao.InterfaceCRUD;

@Service
public class MatiereService<Matiere> implements IMatiereService<Matiere>{

	@Autowired
	InterfaceCRUD<Matiere> matiereDao;
	
	
	
	@Override
	public Matiere findOneById(Long id) {
		
		return matiereDao.getOne(id);
	}

	@Override
	public Matiere save(Matiere t) {
	
		return matiereDao.save(t);
	}

	@Override
	public void delete(Matiere t) {
		matiereDao.delete(t);
		
	}

	@Override
	public List<Matiere> getAll() {
	
		return matiereDao.findAll();
	}

}
