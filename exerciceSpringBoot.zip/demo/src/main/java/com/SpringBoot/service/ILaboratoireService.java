package com.SpringBoot.service;

public interface ILaboratoireService<Laboratoire> extends InterfGeneService<Laboratoire>{

}
