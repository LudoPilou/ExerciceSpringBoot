package com.SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.SpringBoot.dao.InterfaceCRUD;
import com.SpringBoot.entities.Epreuve;
import com.SpringBoot.entities.Etudiant;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		
		ApplicationContext ctx =SpringApplication.run(DemoApplication.class, args);
		InterfaceCRUD pdao = ctx.getBean(com.SpringBoot.dao.InterfaceCRUD.class);
		
	Epreuve epreuve1= new Epreuve();
	pdao.save(epreuve1);
	
	Etudiant etu1 = new Etudiant();
	pdao.save(etu1);
		
	}

}
